<?php
function uiHeader($title){
?>
<!doctype html>
<html>
<head>
	<title><?php echo $title;?></title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/semantic.min.css">
</head>
<body>
	<div class="ui countainer"><?php
}
function uiFooter{
	?>
	</div>
	<script src="js/semantic.min.js">
</body>
</html><?php
}